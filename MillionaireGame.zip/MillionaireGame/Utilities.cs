﻿/*Denna klass innehåller hjälpfunktioner som att hantera inmatningar, valideringar etc...*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MillionaireGame
{
    static class Utilities
    {
        public static void Pause()
        {
            Console.WriteLine("Tryck på [Enter] för att fortsätta...");
            Console.ReadLine();
        }

       
    }
}
